const PROMOTION_TIMER = 3000;

onVisualState((p, state) => {
    if (state.article) {
        p.userData.showClassPromotion = true;
        setTimeout(() => {
            if (p.userData.showClassPromotion) {
                p.showPopup({
                    html: `<div class="info-popup"> <div class="info-popup_header"> </div><div class="info-popup_body"> Interested? Click the microphone button to learn more! </div></div>`,
                    style: `.info-popup{width: 364px;max-width:364px;background:#fff;-webkit-box-shadow:0 5px 14px rgba(0,0,0,.25);box-shadow:0 5px 14px rgba(0,0,0,.25);overflow:hidden;border-radius:10px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.info-popup_body{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:start;-ms-flex-pack:start;justify-content:flex-start;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:91px;font-family:Lato;font-size:18px;color:#000;background:-webkit-gradient(linear,left top,left bottom,from(#e4f2f8),to(#fff));background:-o-linear-gradient(top,#e4f2f8 0,#fff 100%);background:linear-gradient(180deg,#e4f2f8 0,#fff 100%);-ms-flex-negative:1;flex-shrink:1;padding:18px;padding-right: 62px;-webkit-box-sizing:border-box;box-sizing:border-box}.left .info-popup_body{-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end;padding-left: 100px;}.top .info-popup_body{background:-webkit-gradient(linear,left bottom,left top,from(#e4f2f8),to(#fff));background:-o-linear-gradient(bottom,#e4f2f8 0,#fff 100%);background:linear-gradient(0deg,#e4f2f8 0,#fff 100%)}.top .info-popup{-webkit-box-orient:vertical;-webkit-box-direction:reverse;-ms-flex-direction:column-reverse;flex-direction:column-reverse}.info-popup_header{height:174px;background-image:url(https://storage.googleapis.com/alan-public-images/lifeomnic-banner.gif);background-repeat:no-repeat;background-position:center 20px;background-size:contain;-ms-flex-negative:0;flex-shrink:0}`,
                    overlay: false,
                    buttonMarginInPopup: 15
                });
                if (p.userData.isActivated) {
                    runPromotion(p);
                }
            }
        }, PROMOTION_TIMER);
    }
});

onUserEvent((p, e)=> {
    if (e.event === 'firstActivate') {
        p.userData.isActivated = true;
        if (p.visual.article && p.userData.showClassPromotion) {
            runPromotion(p);
        }
    }
});

onCreateUser(p => {
    p.userData.showClassPromotion = true;
});


const interestContext = context(() => {
    
    intent(`(Yes|I am|Interested|Of course|Sure|Hell yeah)`, p => {
        p.play(`Would you prefer 1 on 1 class or a small group class?`);
        p.then(classTypeContext);
    });
    
    intent(`(No|Thanks|Nope|Next time|leave me alone)`, p => {
        p.play(`No problem`);
        p.resolve();
    });
});

function runPromotion(p) {
    p.userData.showClassPromotion = false;
    p.play(`IMF can help with your health goals, but our classes help personalize your approach. Would you be interested?`);
    p.then(interestContext);
}

const classTypeContext = context(() => {
    
    intent(`(1 on 1|personal|individual)`, p => {
        redirect(p);
    });
    
    intent(`(small group|group)`, p => {
        redirect(p, true);
    });
});

function redirect(p, isGroup = false) {
    p.play(`Sure. Redirecting to class Sign up page`);
    p.play({
        command: `singup`,
        article: p.visual.article,
        isGroup,
    });
    p.resolve();
}

project.redirect = redirect;