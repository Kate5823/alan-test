intent(
    `How do I make keto work for me?`, 
    `How do I start keto?`,
    async p => {
        if (!await recommendCoach(p, 'keto')) {
            p.play(`We recommend reading this article`);
            redirect(p, 'https://lifeapps.io/nutrition/the-ketogenic-diet-what-is-it-and-how-does-it-work');
        }
    }
);
intent(`(How do I start fasting?|What type of fasting is right for me?)`, async p => {
    if (!await recommendCoach(p, 'beginner')) {
        p.play(`We recommend reading this article`);
        redirect(p, 'https://lifeapps.io/fasting/a-beginners-guide-to-intermittent-fasting/');
    }
});

// intent(`How can I effectively lose weight fasting?`, p => {
//     // https://lifeapps.io/2020-weight-loss/ https://lifeapps.io/fasting/the-52-diet-works-for-weight-loss/ Also, recommend a coach. A number of them specialize in this
// });

intent(
    `What is the right diet and fasting regimen for me?`, 
    `How do I time fasting to work best for my goals?`,
    async p => {
        p.play(`A fasting schedule should work for your life and your goals. If you'd like to read about each fasting style, check out this article:`);
        if (!await recommendCoach(p, 'fasting')) {
            p.play(`This can help you get started:`);
            redirect(p, 'https://lifeapps.io/fasting/what-fasting-style-is-right-for-you/');
        }
    }
);

intent(
    `Which foods are healthy?`,
    `What the heck should I eat?`,
    `How do I make sure I have enough nutrients when doing intermittent fasting?`,
    `(How do I get enough nutrients during fasting or caloric restriction?|How do I ensure I’m getting the right nutrients?)`,
    `Follow the guidelines in our Nutrition FAQ `,
    p => {
        p.play(
            `Great question! here's a guide`,
        );
        redirect(p, 'https://lifeapps.io/nutrition-faq/');
    },
);

intent(`How do I get rid of unpleasant side effects of fasting?`, p => {
    p.play(`If you're having unpleasant side effects (beyond managable hunger) we advise caution. Speak with one of our experts and review our safety guidelines:`);
    redirect(p, 'https://lifeapps.io/fasting/how-to-practice-intermittent-fasting-safely/');
});

intent(`How do I use fasting for autophagy?`, p => {
    p.play(`Last section in this overview:`);
    redirect(p, 'https://lifeapps.io/fasting/autophagy-the-recycling-mechanism-that-delays-aging-and-prevents-disease/');
});

intent(`(Vegan and fasting?|Vegan and keto?)`, p => {
    p.play(`We don't really cover vegan but they can look for a coach to help them with a personal plan`);
});

intent(`What exercises are best for my body?`, p => {
    p.play(`We recommend working with a coach. for personal fitness evaluations and plans`);
});

intent(`What breaks a fast?`, p => {
    readLongMsg(p, [
        `Technically, anything but water breaks a fast if you’re looking at fasting in its purest definition.`,
        `If [your coffee and tea] are truly plain, they shouldn’t inhibit autophagy or spike your insulin, and you’re still getting all the benefits of fasting.`,
        `I recommend that people stay away from sugar substitutes and heavy creams.`,
        `If you have a significant amount of weight to lose, you will probably still notice some initial weight loss even if you do have cream in your coffee during your fasting window.`,
        `But eventually what I see happen is that people get into plateaus and the ‘dirty fast’ no longer works.`,
        `Your best bet is going to be water, or your black coffee and your plain tea.`,
        `If you don’t like black coffee, delay your cup of coffee [with milk or creamer] until you open your eating window.`,
        `Medicines and over-the-counter medications:`,
        `No. You still need to take your medicines as prescribed, but make sure you can take them on an empty stomach.`,
        `Vitamins and supplements such as coenzyme Q 10: Yes`,
        `Water with lemon or apple cider vinegar: Yes, because of the flavor. But it won’t not make a difference for weight loss.`,
        `Skim milk, MCT oil, butter, heavy cream, coconut oil, artificial or natural sweeteners in your coffee? Yes.`,
        `Celery juice? Yes.`,
        `Gum? Yes, even if it’s sugar free. Most gum has a sweetness to it. Gum starts a cephalic response when you’re anticipating food which could spike insulin.`,
        `Bone broth? Yes. But if you’re new to fasting and you need something to prevent you from eating, you can do it.`,
        `Eventually, you’re going to want to move away from drinking it regularly during fasting.`,
    ]);
});

intent(`What are the best foods to break a fast with?`, p => {
    readLongMsg(p, [
        `I recommend breaking your fast with whole foods. You don’t want to overwhelm your system with a lot of processed foods.`,
        `When you do extended fasting, be careful not to break your fast with a huge, heavy meal.`,
        `Break your fast over a couple hours [to avoid] upsetting your GI.`,
        `I usually break extended fasts (>24 hours) with fermented food (I make my own fermented vegetables) to reseed my gut with healthy gut bacteria and probiotics.`,
        `I wait about 30 minutes and then I’ll have a small, low-fat meal with vegetables and a low-fat cut of fish or chicken.`,
    ]);
});


intent(`How/should I supplement during a fast?`, p => {
    readLongMsg(p, [
        `There are ketone ester supplements available for mass consumption today that can raise your blood ketone levels and help you achieve ketosis.`,
        `For athletes, these supplements may help the body produce ketones that can be advantageous as an energy source during strenuous workouts.`,
        `However, unless you are already on a ketogenic diet these supplements give your body mixed signals in terms of whether it should be burning primarily fats or sugars for fuel.`,
        `These supplements may not be effective or necessarily safe for metabolic health long term, says Dr. Krista Varady.`,
        `Talk to a coach to get personal recommendations.`,
    ]);
});

intent(`What should I eat when doing intermittent fasting?`, p => {
    readLongMsg(p, [
        `Fasting has metabolic health benefits independent of what you are eating during your feeding periods.`,
        `However, fasting will not turn a junk food diet into a good one.`,
        `In a study of people practicing IF and eating either a regular (25% fat) or high-fat diet (45% fat),`,
        `Dr. Krista Varady found no significant differences in metabolic health between these two treatment groups over time.`,
        `Each group displayed similar decreases in weight and coronary heart disease risk factors including LDL cholesterol and triglyceride levels.`,
        `Varady is currently exploring whether there are any links between fasting, low-carb diets and improved metabolic health.`,
        `Many people who practice IF pair their fasting schedule with a ketogenic or very low-carb diet.`,
        `However, there is little scientific research from human trials to determine any benefits or issues of pairing these interventions.`,
        `The problem with ketogenic dieting is that it often leads people to eat an overabundance of unhealthy animal fats as opposed to healthier plant fats.`,
        `“I’d recommend eating your typical American Heart Association diet, or a balanced diet of protein, carbs and fats,” Dr. Krista Varady says.`,
    ]);
});

intent(`How do I deal with hunger?`, p => {
    readLongMsg(p, [
        `Studies of intermittent fasting have generally not shown any significant impacts on ghrelin, the gut hunger hormone.`,
        `It’s normal to feel hungry while fasted, even after practicing intermittent fasting for several months.`,
        `You may find that over time, however, you are better able to deal with feelings of hunger and better able to distinguish between actual hunger and externally triggered food cravings, for example.`,
        `Drinking plenty of calorie-free fluids or eating up to 500 calories on a fast day can help manage your feelings of hunger while in a fasted state.`,
    ]);
});

intent(`What exercise should I do when fasting?`, p => {
    readLongMsg(p, [
        `We often have paid sessions for fasted exercise.`,
        `Here's the FAQ answer:`,
        `combining fasting with endurance exercise can produce superior changes in body weight,`,
        `body composition and lipid indicators of heart disease risk, compared to either exercise or fasting alone.`,
        `Contrary to popular belief, it is safe to exercise on alternate fast days or during fasts not exceeding 24 hours.`,
        `In fact, in studies of IF, research participants often report boosts of energy on days when they fast or eat fewer than 500 calories.`,
        `“In the first 10 days of an alternate day fasting practice, you may notice decreases in energy or concentration levels,”`,
        `Dr. Krista Varady says. “But after these first 10 days, most people find it easy to still exercise on their fast days.”`,
        `In one of the first studies to combine fasting and exercise interventions,`,
        `Varady ran a 12-week study of intermittent fasting combined with endurance exercise (brisk walking / cycling).`,
        `Obese research participants on an alternate day fasting schedule came into the lab three days per week to exercise on stationary bikes and treadmills.`,
        `When given the option of training during either “feast” or fast days, participants chose to exercise on fast days just as often as on feast days.`,
        `If your primary goal is weight loss, however, you may also want to wait until after exercise to eat during an alternate fast day, according to Varady’s study.`,
        `Participants who consumed their one allotted fast day meal before exercise tended to get a burst of hunger an hour or so after exercising, leading them to often cheat and eat extra calories that day.`,
    ]);
});

intent(`How do I get into ketosis?`, p => {
    readLongMsg(p, [
        `It can take anywhere from 12 to 24 hours to get into a state of partial ketosis.`,
        `During a fast, once your serum glucose level drops by 20% your liver will start producing ketones to supplement the energy your brain needs.`,
        `Achieving full ketosis can up to 10 days on a ketogenic diet.`,
        `Upon entering ketosis, some people notice a fruity smell on their breath, a decrease in appetite or lethargy, while other people don’t experience these symptoms at all.`,
        `Remaining in full ketosis over time requires consuming fewer than 30 grams of carbohydrates per day.`,
        `The metabolic benefits of intermittent fasting, however, don’t depend on achieving a state of full ketosis while fasting.`,
        `In studies of healthy obese individuals, Dr. Krista Varady has observed insulin resistance levels decrease by up to 40% when these individuals stick to an IF regimen for just a few weeks.`,
    ]);
});

intent(`Will fasting help me?`, p => {
    p.play(`Fasting can help you with many health goals. Talk to a coach to get a personalized plan.`);
});

intent(`How do I manage hunger and cravings?`, p => {
    p.play(`We have a lot of sessions and coaches that can help with this.`);
});

intent(`Fasting and medications?`, p => {
    p.play(`You still need to take your medicines as prescribed, but make sure you can take them on an empty stomach.`);
});

intent(`How will caloric restriction affect me?`, p => {
    p.play(`Healthier food choices and greater calorie restriction in conjunction with any IF schedule can help you accelerate weight loss. Safe caloric restriction can also help promote longevity.`);
});

function recommendCoach(p, coachType) {
    p.userData.showClassPromotion = false;
    p.play(`Since each person is different, we recommend getting a personalized plan with one of our coaches.`);
    p.play(`Would you like to do that?`);
    
    return p.then(recommendContext, {state: { coachType }});
}

const recommendContext = context(() => {

    intent(`yes`, p => {
        p.resolve(true);
        project.redirect(p, p.state.coachType, false);
    });
    
    intent(`no`, p => {
        p.resolve(false);
        p.play(`Ok`);
    });
});

function redirect(p, article) {
    p.play({
        command: 'redirect',
        article,
    });
}

function readLongMsg(p, msgs) {
    p.play(msgs[0]);
    p.play(`Do you want to hear more?`);
    p.then(longMsgContext, {state: {msgs: msgs.slice(1)}});
}

const longMsgContext = context(() => {

    intent(`yes`, p => {
        p.state.msgs.forEach(msg => p.play(msg));
        p.resolve();
    });

    intent(`no`, p => {
        p.play(`Ok`);
        p.resolve();
    });
});
